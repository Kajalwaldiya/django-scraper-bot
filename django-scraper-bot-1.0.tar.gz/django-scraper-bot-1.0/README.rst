=====
SCRAPER BOT
=====

Quick start
-----------

1. Add "polls" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'bot_app',
    ]

2. Include the bot URLconf in your project urls.py like this::

    url(r'^scraper_bot/', include('bot_app.urls')),

3. Run `python manage.py migrate` to create the polls models.

4. Visit http://127.0.0.1:8000/scraper_bot/ to participate in the poll.
